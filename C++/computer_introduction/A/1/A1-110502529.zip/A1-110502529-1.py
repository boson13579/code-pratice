"""
Assignment : 1-1
Name : 陳柏燊
Student number : 110502529
Course : 2021-CE1003-A

"""

a = input("input1:")
b = input("input2:")
c = input("input3:")
print(c, b, a)