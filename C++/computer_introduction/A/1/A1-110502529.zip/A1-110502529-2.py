"""
Assignment : 1-2
Name : 陳柏燊
Student number : 110502529
Course : 2021-CE1003-A

"""

a = int(input())
b = int(input())

print(a+b)
print(a-b)
print(a*b)
print(a/b)
print(a**b)
print(a//b)
print(a%b)
