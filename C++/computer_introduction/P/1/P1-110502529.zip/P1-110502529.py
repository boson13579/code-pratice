"""
Practice : 1
Name : 陳柏燊
Student number : 110502529
Course : 2021-CE1003-A

"""

a = input()
print("hello world " + a)